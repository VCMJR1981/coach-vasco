# Coach Vasco — Knowledge Library

## What this is
The complete science library powering the Coach Vasco AI coaching agent.
Built by Vasco (Concrete Surfers / The Confident Surfer) over multiple research sessions.

## Structure
Each module is a self-contained JSON file:
```
{
  "module": "module_name",
  "version": "1.0", 
  "keywords": ["trigger", "words", ...],
  "content": "Full coaching content backed by peer-reviewed research"
}
```

## Modules (13 + core)

| Module | Studies | Key Topics |
|--------|---------|------------|
| core | — | Coach Vasco identity, voice, CSTM methodology |
| popup | Eurich 2010, Borgonovo-Santos 2021 | Biomechanics, phases, front foot loading |
| surfskate | CSTM | L1-L2 progression, pumping, all manoeuvres |
| strength_power | Calatayud 2020, Wang 2025, Dann 2024 | Gym training, TRX protocol, RLD |
| paddling | Tran et al. | Sprint/endurance paddle, shoulder health |
| injury | Multiple | Prevention, rotator cuff, warm-up |
| nutrition | 5 studies | LEA, female athlete fuelling, surf travel |
| competition | Multiple | Judging, heat strategy, benchmarks |
| periodization | Dann 2024 | Annual planning, RLD framework, dry-land |
| technique | Dunn Vol.1-3 | Bottom turn, cutback, tube, aerial — full library |
| physiology | 5 studies | Aerobic/anaerobic demands, fitness testing |
| wave_reading | Buckley 2019 | Timescale framework, lineup strategy |
| mental | Lange-Smith 2024, Liu 2025, Bordo 2025 | PST, imagery dosage, breathing |
| flexibility | Simic 2013 | Mobility protocols, surf yoga, warm-up |

## How to add a new study
1. Open the relevant module JSON
2. Add content under the `content` field following the existing format
3. Add any new trigger keywords to the `keywords` array
4. Update `version` and `last_updated`

## How to add a new module
1. Create `new_module.json` following the template above
2. Add entry to `index.json`
3. Add the module to the app's selector function

## This library is yours
The science, the coaching protocols, the CSTM methodology — all proprietary.
Independent of any AI model. Portable to any future platform.
